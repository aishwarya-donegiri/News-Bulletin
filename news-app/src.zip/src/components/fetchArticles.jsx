import React, { Component } from "react";
import Cards from "./cards";
import { css } from "@emotion/core";
import BounceLoader from "react-spinners/BounceLoader";

class FetchArticles extends Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      articles: [],

      //url: this.props.url,
    };
  }
  // state = {
  //   error: null,
  //   isLoaded: false,
  //   items: [],
  //   url: this.props.url,
  // };

  fetchFromUrl = (newUrl) => {
    //console.log("fetch");
    //console.log(newUrl);
    fetch(newUrl)
      .then((res) => res.json())
      .then(
        (result) => {
          //console.log(typeof this.state.articles);
          //console.log(result);

          this.setState({
            isLoaded: true,
            articles: result,
          });

          //console.log(this.state.articles[1]);
        },
        (error) => {
          console.log("Error");
          this.setState({
            isLoaded: true,
            error,
          });
        }
      );
  };

  componentDidMount() {
    //console.log("mounted");
    let url;
    if (this.props.guardian) {
      url = "http://localhost:3001/home/guardian";
    } else {
      url = "http://localhost:3001/home/nyt";
    }
    this.fetchFromUrl(url);
  }

  componentDidUpdate(prevProps) {
    //console.log(prevProps, this.props);
    if (this.props.guardian !== prevProps.guardian) {
      let url;
      if (this.props.guardian) {
        url = "http://localhost:3001/home/guardian";
      } else {
        url = "http://localhost:3001/home/nyt";
      }
      if (this.state.isLoaded) {
        this.setState({ isLoaded: false });
      }
      this.fetchFromUrl(url);
    }
  }

  render() {
    //console.log("homPage", this.state);
    const { error, isLoaded, articles } = this.state;
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return (
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            margin: "-50px 0px 0px -50px",
          }}
        >
          <BounceLoader css="" size="50px" color={"#325aba"} loading={true} />

          <div className="mt-1"> Loading</div>
        </div>
      );
    } else {
      return (
        <React.Fragment>
          {articles.length == 0 ? (
            <h6>You have no saved articles</h6>
          ) : (
            <Cards articles={articles} />
          )}
        </React.Fragment>
      );
    }
  }
}

export default FetchArticles;
