import React, { Component } from "react";

class Test extends Component {
  state = {};
  render() {
    return <h1>{this.props.match.params.section}</h1>;
  }
}

export default Test;
