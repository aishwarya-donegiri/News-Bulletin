import React, { Component } from "react";
//import { BrowserRouter, Route, Switch } from "react-router-dom";
import NavigationBar from "./components/navBar";
import "./App.css";
//import HomePage from "./components/homePage";
import Content from "./components/content";

class App extends Component {
  state = {
    toggleIsVisible: true,
    guardian: localStorage.getItem("guardian") === "true",
  };

  componentDidMount() {}

  setToggle = () => {
    //console.log("toggled");
    let guardian;
    this.state.guardian ? (guardian = false) : (guardian = true);
    this.setState({ guardian }, () => {
      localStorage.setItem("guardian", this.state.guardian);
    });

    //console.log(this.state.guardian);
  };

  setToggleVisibility = () => {
    //console.log("deactivated");
    let toggleIsVisible;
    this.state.toggleIsVisible
      ? (toggleIsVisible = false)
      : (toggleIsVisible = true);
    this.setState({ toggleIsVisible });
  };

  render() {
    //console.log(this.state.url);
    return (
      <React.Fragment>
        <NavigationBar
          test={this.test}
          guardian={this.state.guardian}
          setToggle={this.setToggle}
          toggleIsVisible={this.state.toggleIsVisible}
        />
        <Content
          guardian={this.state.guardian}
          setToggleVisibility={this.setToggleVisibility}
          toggleIsVisible={this.state.toggleIsVisible}
        />
      </React.Fragment>
    );
  }
}

export default App;
